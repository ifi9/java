module com.in28minutes.service.provider {
	exports com.in28minutes.sorting.util;
	exports com.in28minutes.sorting.algorithm;
}