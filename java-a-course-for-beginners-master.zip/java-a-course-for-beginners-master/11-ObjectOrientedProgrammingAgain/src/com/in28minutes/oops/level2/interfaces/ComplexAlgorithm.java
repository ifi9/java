package com.in28minutes.oops.level2.interfaces;

public interface ComplexAlgorithm {
	int complexAlgorithm(int number1, int number2);
}
