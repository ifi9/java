package com.in28minutes.tips.eclipse;

import java.util.ArrayList;
import java.util.List;

public class DummyForTest {

	public void doSomething() {
		List list = new ArrayList();
	}

}
