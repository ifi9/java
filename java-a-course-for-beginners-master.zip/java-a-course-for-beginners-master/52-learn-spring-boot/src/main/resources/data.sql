insert into COURSE (ID, AUTHOR, NAME)
values (100001, 'in28minutes', 'Learn Microservices'); 
insert into COURSE (ID, AUTHOR, NAME)
values (100002, 'in28minutes', 'Learn FullStack with React and Angular'); 
insert into COURSE (ID, AUTHOR, NAME)
values (100003, 'in28minutes', 'Learn AWS, GCP and Azure'); 